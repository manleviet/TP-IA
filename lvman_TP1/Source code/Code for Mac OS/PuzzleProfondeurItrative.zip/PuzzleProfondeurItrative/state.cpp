#include "state.h"
#include <QObject>

State::State(State *parentState, int limiteNew, int stateNew[9])
{
    parent = parentState;
    limite = limiteNew;
    for (int i = 0; i < 9; i++)
        state[i] = stateNew[i];
}

void State::addChildren(State *stateChildren)
{
    children.append(stateChildren);
}

QString State::toString()
{
    QString temp;
    int count = 0;
    for (int i = 0; i < 9; i++)
    {
        temp += QObject::tr("%1 ").arg(state[i]);
        count++;
        if (count == 3)
        {
            count = 0;
            temp += "\n";
        }
    }
    return temp;
}

bool State::equal(State *stateOther)
{
    for (int i = 0; i < 9; i++)
    {
        if (stateOther->at(i) != state[i])
            return false;
    }
    return true;
}

QList<State *> State::successeur(State *parent)
{
    QList<State *> temp;

    // tim vi tri cua gia tri 0
    int pos = 8;
    for (int i = 0; i < 9; i++)
        if (state[i] == 0)
        {
            pos = i;
            break;
        }

    // dua vao pos ta tao ra so state successeur tuong ung
    // vao hoan chuyen gia tri cho hop ly
    int s1[9];
    int s2[9];
    int s3[9];
    int s4[9];

    State *state1;
    State *state2;
    State *state3;
    State *state4;

    int limite = parent->getLimite() + 1;

    switch(pos)
    {
    case 0:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, limite, s1);
        state2 = new State(parent, limite, s2);
        state1->exchangeValue(0, 1);
        state2->exchangeValue(0, 3);
        temp.append(state1);
        temp.append(state2);
        break;
    case 1:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, limite, s1);
        state2 = new State(parent, limite, s2);
        state3 = new State(parent, limite, s3);
        state1->exchangeValue(0, 1);
        state2->exchangeValue(1, 2);
        state3->exchangeValue(1, 4);
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 2:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, limite, s1);
        state2 = new State(parent, limite, s2);
        state1->exchangeValue(1, 2);
        state2->exchangeValue(2, 5);
        temp.append(state1);
        temp.append(state2);
        break;
    case 3:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, limite, s1);
        state2 = new State(parent, limite, s2);
        state3 = new State(parent, limite, s3);
        state1->exchangeValue(3, 0);
        state2->exchangeValue(3, 4);
        state3->exchangeValue(3, 6);
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 4:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        this->copy(s4);
        state1 = new State(parent, limite, s1);
        state2 = new State(parent, limite, s2);
        state3 = new State(parent, limite, s3);
        state4 = new State(parent, limite, s4);
        state1->exchangeValue(4, 1);
        state2->exchangeValue(4, 3);
        state3->exchangeValue(4, 5);
        state4->exchangeValue(4, 7);
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        temp.append(state4);
        break;
    case 5:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, limite, s1);
        state2 = new State(parent, limite, s2);
        state3 = new State(parent, limite, s3);
        state1->exchangeValue(5, 2);
        state2->exchangeValue(5, 4);
        state3->exchangeValue(5, 8);
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 6:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, limite, s1);
        state2 = new State(parent, limite, s2);
        state1->exchangeValue(6, 3);
        state2->exchangeValue(6, 7);
        temp.append(state1);
        temp.append(state2);
        break;
    case 7:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, limite, s1);
        state2 = new State(parent, limite, s2);
        state3 = new State(parent, limite, s3);
        state1->exchangeValue(7, 6);
        state2->exchangeValue(7, 4);
        state3->exchangeValue(7, 8);
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 8:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, limite, s1);
        state2 = new State(parent, limite, s2);
        state1->exchangeValue(8, 7);
        state2->exchangeValue(8, 5);
        temp.append(state1);
        temp.append(state2);
        break;
    };

    return temp;
}

void State::copy(int stateOther[])
{
    for (int i = 0; i < 9; i++)
        stateOther[i] = state[i];
}

void State::exchangeValue(int posi, int posj)
{
    int temp = state[posi];
    state[posi] = state[posj];
    state[posj] = temp;
}
