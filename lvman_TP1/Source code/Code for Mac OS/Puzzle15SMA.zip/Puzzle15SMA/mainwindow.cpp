#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QStringList>
#include <QTime>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    int finalstate[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,0};
    finalState = new State(0, 0, finalstate);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::newButtonClicked()
{
    ui->inputLineEdit->clear();
    ui->outputTextEdit->clear();
}

void MainWindow::solveButtonClicked()
{
    QStringList fields = ui->inputLineEdit->text().split(" ");
    if (fields.length() != 16) return;

    int state[16];
    for (int i = 0; i < 16; i++)
        state[i] = fields.at(i).toInt();

    initialState = new State(0, 0, state);

    QTime time = QTime::currentTime();

    bool check = solve(initialState, finalState);

    QTime time1 = QTime::currentTime();

    ui->outputTextEdit->setText(this->printOutput(check, time.secsTo(time1)));
    ui->solutionTextEdit->setText(this->printSolution(check));
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

bool MainWindow::solve(State *initialState, State *finalState)
{
    open.clear();
    close.clear();

    open.append(initialState);

    while (!open.isEmpty())
    {
        int pos = choisirStateMinF(open);
        State *temp = open.at(pos);
        if (!this->constaint(close, temp))
        {
            close.append(temp);
        }

        if (temp->equal(finalState))
        {
            return true;
        }
        else
        {
            QList<State *> succ = temp->successeur(temp);
            // loai bo nhung succ da duyet
            int i = 0;
            while (i < succ.length())
            {
                bool check = false;
                for (int j = 0; j < open.length(); j++)
                    if (succ.at(i)->equal(open.at(j)))
                    {
                        check = true;
                        break;
                    }
                if (!check)
                {
                    for (int j = 0; j < close.length(); j++)
                        if (succ.at(i)->equal(close.at(j)))
                        {
                            check = true;
                            break;
                        }
                }
                i++;
                // neu da co thi se khong xet den nua
                if (check)
                {
                    i--;
                    succ.removeAt(i);
                }
            }

            if (!succ.isEmpty())
            {
                // lay ra thang tot nhat
                int posBest = this->choisirStateMinF(succ);
                State *best = succ.at(posBest);
                temp->addChildren(best);
                open.append(best);
                succ.removeAt(posBest);

                // lay ra thang tot nhi
                if (succ.isEmpty()) // khi khong con thang nao
                {
                    open.removeAt(pos);
                }
                else // khi con nhieu thang trong succ
                {
                    posBest = this->choisirStateMinF(succ);
                    temp->setF(succ.at(posBest)->getF());
                }
            }
            else // succ la rong
            {
                open.removeAt(pos);
            }
        }

        while (open.length() > 100)
        {
            int posMaxF = this->choisirStateMaxF(open);
            if (this->constaint(close, open.at(posMaxF)))
            {
                close.append(open.at(posMaxF));
            }
            open.removeAt(posMaxF);
        }
    }

    return false;
}

QString MainWindow::printOutput(bool check, int time)
{
    QString temp;
    temp += "Probleme :\n";
    temp += initialState->toString() + "\n";

    if (!check)
        temp += "Ce probleme ne peut pas resoudre !\n";

    temp +="LES ESTAPES\n";

    for (int i = 0; i < close.length(); i++)
    {
        temp += QObject::tr("Etape %1 :\n").arg(i);
        temp += close.at(i)->toString() + "\n";
    }

    temp += QObject::tr("Somme de noeuds nes : %1 \n").arg(close.length() + open.length());
    temp += QObject::tr("Somme d'etapes exploitees : %1 \n").arg(close.length());
    temp += QObject::tr("Temps : %1 secondes").arg(time);

    return temp;
}

QString MainWindow::printSolution(bool check)
{
    QString temp = "";

    if (!check)
    {
        temp += "Ce probleme ne peut pas resoudre !";
    }
    else
    {
        State *state = close.last();
        int count = 0;
        while (state != 0)
        {
            count++;
            temp = state->toString() + "\n" + temp;
            state = state->getParent();
        }

        temp += QObject::tr("Somme d'etapes necessaires : %1").arg(count);
    }

    return temp;
}

int MainWindow::choisirStateMinF(QList<State *> list)
{
    int min = 1000000;
    int pos = 0;
    for (int i = 0; i < list.length(); i++)
    {
        if (min > (list.at(i)->getF()))
        {
            min = list.at(i)->getF();
            pos = i;
        }
    }

    return pos;
}

int MainWindow::choisirStateMaxF(QList<State *> list)
{
    int max = 0;
    int pos = 0;
    for (int i = 0; i < list.length(); i++)
    {
        if (max < (list.at(i)->getF()))
        {
            max = list.at(i)->getF();
            pos = i;
        }
    }

    return pos;
}

bool MainWindow::constaint(QList<State *> list, State *state)
{
    for (int i = 0; i < list.length(); i++)
        if (state->equal(list.at(i)))
            return true;
    return false;
}
