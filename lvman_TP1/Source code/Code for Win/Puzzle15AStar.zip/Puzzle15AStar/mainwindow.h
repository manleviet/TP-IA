#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "state.h"

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

public slots:
    void newButtonClicked();
    void solveButtonClicked();

protected:
    void changeEvent(QEvent *e);

private:
    bool solve(State *initialState, State *finalState);
    QString printOutput(bool check, int time);
    QString printSolution(bool check);
    int choisirState(QList<State *> list);

    Ui::MainWindow *ui;

    State *initialState;
    State *finalState;

    QList<State *> close;
    QList<State *> open;
};

#endif // MAINWINDOW_H
