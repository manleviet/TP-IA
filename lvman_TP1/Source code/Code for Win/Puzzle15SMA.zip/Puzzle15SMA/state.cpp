#include "state.h"
#include <QObject>

State::State(State *parentState, int cout, int stateNew[16])
{
    parent = parentState;
    g = cout;
    for (int i = 0; i < 16; i++)
        state[i] = stateNew[i];
    h = calculateH();
    f = g + h;
}

void State::addChildren(State *stateChildren)
{
    children.append(stateChildren);
}

void State::updateH()
{
    h = calculateH();
    f = h + g;
}

QString State::toString()
{
    QString temp;
    int count = 0;
    for (int i = 0; i < 16; i++)
    {
        temp += QObject::tr("%1 ").arg(state[i]);
        count++;
        if (count == 4)
        {
            count = 0;
            temp += "\n";
        }
    }
    return temp;
}

bool State::equal(State *stateOther)
{
    for (int i = 0; i < 16; i++)
    {
        if (stateOther->at(i) != state[i])
            return false;
    }
    return true;
}

QList<State *> State::successeur(State *parent)
{
    QList<State *> temp;

    // tim vi tri cua gia tri 0
    int pos = 15;
    for (int i = 0; i < 16; i++)
        if (state[i] == 0)
        {
            pos = i;
            break;
        }

    // dua vao pos ta tao ra so state successeur tuong ung
    // vao hoan chuyen gia tri cho hop ly
    int s1[16];
    int s2[16];
    int s3[16];
    int s4[16];

    State *state1;
    State *state2;
    State *state3;
    State *state4;

    switch(pos)
    {
    case 0:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state1->exchangeValue(0, 1);
        state2->exchangeValue(0, 4);
        state1->updateH();
        state2->updateH();
        temp.append(state1);
        temp.append(state2);
        break;
    case 1:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(1, 0);
        state2->exchangeValue(1, 2);
        state3->exchangeValue(1, 5);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 2:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(2, 1);
        state2->exchangeValue(2, 6);
        state3->exchangeValue(2, 3);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 3:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state1->exchangeValue(3, 2);
        state2->exchangeValue(3, 7);
        state1->updateH();
        state2->updateH();
        temp.append(state1);
        temp.append(state2);
        break;
    case 4:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(4, 0);
        state2->exchangeValue(4, 5);
        state3->exchangeValue(4, 8);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 5:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        this->copy(s4);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state4 = new State(parent, g+1, s4);
        state1->exchangeValue(5, 1);
        state2->exchangeValue(5, 4);
        state3->exchangeValue(5, 6);
        state4->exchangeValue(5, 9);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        state4->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        temp.append(state4);
        break;
    case 6:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        this->copy(s4);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state4 = new State(parent, g+1, s4);
        state1->exchangeValue(6, 2);
        state2->exchangeValue(6, 5);
        state3->exchangeValue(6, 7);
        state4->exchangeValue(6, 10);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        state4->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        temp.append(state4);
        break;
    case 7:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(7, 3);
        state2->exchangeValue(7, 6);
        state3->exchangeValue(7, 11);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 8:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(8, 4);
        state2->exchangeValue(8, 9);
        state3->exchangeValue(8, 12);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 9:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        this->copy(s4);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state4 = new State(parent, g+1, s4);
        state1->exchangeValue(9, 5);
        state2->exchangeValue(9, 8);
        state3->exchangeValue(9, 10);
        state4->exchangeValue(9, 13);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        state4->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        temp.append(state4);
        break;
    case 10:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        this->copy(s4);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state4 = new State(parent, g+1, s4);
        state1->exchangeValue(10, 6);
        state2->exchangeValue(10, 9);
        state3->exchangeValue(10, 11);
        state4->exchangeValue(10, 14);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        state4->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        temp.append(state4);
        break;
    case 11:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(11, 7);
        state2->exchangeValue(11, 10);
        state3->exchangeValue(11, 15);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 12:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state1->exchangeValue(12, 8);
        state2->exchangeValue(12, 13);
        state1->updateH();
        state2->updateH();
        temp.append(state1);
        temp.append(state2);
        break;
    case 13:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(13, 9);
        state2->exchangeValue(13, 12);
        state3->exchangeValue(13, 14);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 14:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(14, 10);
        state2->exchangeValue(14, 13);
        state3->exchangeValue(14, 15);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 15:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state1->exchangeValue(15, 11);
        state2->exchangeValue(15, 14);
        state1->updateH();
        state2->updateH();
        temp.append(state1);
        temp.append(state2);
        break;
    };

    return temp;
}

void State::copy(int stateOther[])
{
    for (int i = 0; i < 16; i++)
        stateOther[i] = state[i];
}

void State::exchangeValue(int posi, int posj)
{
    int temp = state[posi];
    state[posi] = state[posj];
    state[posj] = temp;
}

int State::calculateH()
{
    // su dung Manhatan
    int hTemp = 0;
    for (int i = 0; i < 16; i++)
    {
        int xSolution = ordinateX(i);
        int ySolution = ordinateY(i);

        int pos;
        if (state[i] == 0)
            pos = 15;
        else
            pos = state[i] - 1;

        int x = ordinateX(pos);
        int y = ordinateY(pos);

        hTemp += qAbs(x - xSolution) + qAbs(y - ySolution);
    }
    return hTemp;
}

int State::ordinateX(int index)
{
    return (int)(index / 4.0);
}

int State::ordinateY(int index)
{
    int temp = index;
    while (temp >= 4)
    {
        temp = temp - 4;
    }
    return temp;
}
