#ifndef STATE_H
#define STATE_H

#include <QList>

class State
{
public:
    State(State *parent, int stateNew[9]);

    void addChildren(State *stateChildren);
    State *getParent() {return parent;}

    int at(int index) {return state[index];}
    QString toString();

    bool operator== (State* stateOther);
    bool equal(State *stateOther);

    QList<State *> successeur(State *parent);

private:
    void copy(int state[9]);
    void exchangeValue(int posi, int posj);

    int state[9];

    State *parent;
    QList<State *> children;
};

#endif // STATE_H
