#ifndef STATE_H
#define STATE_H

#include <QList>

class State
{
public:
    State(State *parent, int cout, int stateNew[9]);

    void addChildren(State *stateChildren);
    State *getParent() {return parent;}

    int getH() {return h;}
    void updateH();
    int getG() {return g;}

    int at(int index) {return state[index];}
    QString toString();

    bool equal(State *stateOther);

    QList<State *> successeur(State *parent);

private:
    void copy(int state[9]);
    void exchangeValue(int posi, int posj);
    int calculateH();
    int ordinateX(int index);
    int ordinateY(int index);

    int state[9];
    int h;
    int g;

    State *parent;
    QList<State *> children;
};

#endif // STATE_H
