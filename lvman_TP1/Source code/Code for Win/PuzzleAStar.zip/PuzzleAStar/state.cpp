#include "state.h"
#include <QObject>

State::State(State *parentState, int cout, int stateNew[9])
{
    parent = parentState;
    g = cout;
    for (int i = 0; i < 9; i++)
        state[i] = stateNew[i];
    h = calculateH();
}

void State::addChildren(State *stateChildren)
{
    children.append(stateChildren);
}

void State::updateH()
{
    h = calculateH();
}

QString State::toString()
{
    QString temp;
    int count = 0;
    for (int i = 0; i < 9; i++)
    {
        temp += QObject::tr("%1 ").arg(state[i]);
        count++;
        if (count == 3)
        {
            count = 0;
            temp += "\n";
        }
    }
    return temp;
}

bool State::equal(State *stateOther)
{
    for (int i = 0; i < 9; i++)
    {
        if (stateOther->at(i) != state[i])
            return false;
    }
    return true;
}

QList<State *> State::successeur(State *parent)
{
    QList<State *> temp;

    // tim vi tri cua gia tri 0
    int pos = 8;
    for (int i = 0; i < 9; i++)
        if (state[i] == 0)
        {
            pos = i;
            break;
        }

    // dua vao pos ta tao ra so state successeur tuong ung
    // vao hoan chuyen gia tri cho hop ly
    int s1[9];
    int s2[9];
    int s3[9];
    int s4[9];

    State *state1;
    State *state2;
    State *state3;
    State *state4;

    switch(pos)
    {
    case 0:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state1->exchangeValue(0, 1);
        state2->exchangeValue(0, 3);
        state1->updateH();
        state2->updateH();
        temp.append(state1);
        temp.append(state2);
        break;
    case 1:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(0, 1);
        state2->exchangeValue(1, 2);
        state3->exchangeValue(1, 4);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 2:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state1->exchangeValue(1, 2);
        state2->exchangeValue(2, 5);
        state1->updateH();
        state2->updateH();
        temp.append(state1);
        temp.append(state2);
        break;
    case 3:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(3, 0);
        state2->exchangeValue(3, 4);
        state3->exchangeValue(3, 6);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 4:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        this->copy(s4);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state4 = new State(parent, g+1, s4);
        state1->exchangeValue(4, 1);
        state2->exchangeValue(4, 3);
        state3->exchangeValue(4, 5);
        state4->exchangeValue(4, 7);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        state4->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        temp.append(state4);
        break;
    case 5:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(5, 2);
        state2->exchangeValue(5, 4);
        state3->exchangeValue(5, 8);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 6:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state1->exchangeValue(6, 3);
        state2->exchangeValue(6, 7);
        state1->updateH();
        state2->updateH();
        temp.append(state1);
        temp.append(state2);
        break;
    case 7:
        this->copy(s1);
        this->copy(s2);
        this->copy(s3);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state3 = new State(parent, g+1, s3);
        state1->exchangeValue(7, 6);
        state2->exchangeValue(7, 4);
        state3->exchangeValue(7, 8);
        state1->updateH();
        state2->updateH();
        state3->updateH();
        temp.append(state1);
        temp.append(state2);
        temp.append(state3);
        break;
    case 8:
        this->copy(s1);
        this->copy(s2);
        state1 = new State(parent, g+1, s1);
        state2 = new State(parent, g+1, s2);
        state1->exchangeValue(8, 7);
        state2->exchangeValue(8, 5);
        state1->updateH();
        state2->updateH();
        temp.append(state1);
        temp.append(state2);
        break;
    };

    return temp;
}

void State::copy(int stateOther[])
{
    for (int i = 0; i < 9; i++)
        stateOther[i] = state[i];
}

void State::exchangeValue(int posi, int posj)
{
    int temp = state[posi];
    state[posi] = state[posj];
    state[posj] = temp;
}

int State::calculateH()
{
    // su dung Manhatan
    int hTemp = 0;
    for (int i = 0; i < 9; i++)
    {
        int xSolution = ordinateX(i);
        int ySolution = ordinateY(i);

        int pos;
        if (state[i] == 0)
            pos = 8;
        else
            pos = state[i] - 1;

        int x = ordinateX(pos);
        int y = ordinateY(pos);

        hTemp += qAbs(x - xSolution) + qAbs(y - ySolution);
    }
    return hTemp;
}

int State::ordinateX(int index)
{
    return (int)(index / 3.0);
}

int State::ordinateY(int index)
{
    int temp = index;
    while (temp >= 3)
    {
        temp = temp - 3;
    }
    return temp;
}
