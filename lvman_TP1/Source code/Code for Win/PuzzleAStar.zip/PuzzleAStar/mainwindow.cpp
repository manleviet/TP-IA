#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMessageBox>
#include <QStringList>
#include <QTime>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    int finalstate[9] = {1,2,3,4,5,6,7,8,0};
    finalState = new State(0, 0, finalstate);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::newButtonClicked()
{
    ui->inputLineEdit->clear();
    ui->outputTextEdit->clear();
}

void MainWindow::solveButtonClicked()
{
    QStringList fields = ui->inputLineEdit->text().split(" ");
    if (fields.length() != 9) return;

    int state[9];
    for (int i = 0; i < 9; i++)
        state[i] = fields.at(i).toInt();

    initialState = new State(0, 0, state);

    QTime time = QTime::currentTime();

    bool check = solve(initialState, finalState);

    QTime time1 = QTime::currentTime();

    ui->outputTextEdit->setText(this->printOutput(check, time.secsTo(time1)));
    ui->solutionTextEdit->setText(this->printSolution(check));
}

void MainWindow::changeEvent(QEvent *e)
{
    QMainWindow::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        ui->retranslateUi(this);
        break;
    default:
        break;
    }
}

bool MainWindow::solve(State *initialState, State *finalState)
{
    open.clear();
    close.clear();

    open.append(initialState);

    while (!open.isEmpty())
    {
        int pos = choisirState(open);
        State *temp = open.at(pos);
        open.removeAt(pos);
        close.append(temp);

        if (temp->equal(finalState))
        {
            return true;
        }
        else
        {
            QList<State *> succ = temp->successeur(temp);
            for (int i = 0; i < succ.length(); i++)
            {
                bool check = false;
                for (int j = 0; j < open.length(); j++)
                    if (succ.at(i)->equal(open.at(j)))
                    {
                        check = true;
                        break;
                    }
                if (!check)
                    for (int j = 0; j < close.length(); j++)
                        if (succ.at(i)->equal(close.at(j)))
                        {
                            check = true;
                            break;
                        }
                if (!check)
                {
                    temp->addChildren(succ.at(i));
                    open.append(succ.at(i));
                }
            }
        }
    }

    return false;
}

QString MainWindow::printOutput(bool check, int time)
{
    QString temp;
    temp += "Probleme :\n";
    temp += initialState->toString() + "\n";

    if (!check)
        temp += "Ce probleme ne peut pas resoudre !\n";

    temp +="LES ESTAPES\n";

    for (int i = 0; i < close.length(); i++)
    {
        temp += QObject::tr("Etape %1 :\n").arg(i);
        temp += close.at(i)->toString() + "\n";
    }

    temp += QObject::tr("Somme de noeuds nes : %1 \n").arg(close.length() + open.length());
    temp += QObject::tr("Somme d'etapes exploitees : %1 \n").arg(close.length());
    temp += QObject::tr("Temps : %1 secondes").arg(time);

    return temp;
}

QString MainWindow::printSolution(bool check)
{
    QString temp = "";

    if (!check)
    {
        temp += "Ce probleme ne peut pas resoudre !";
    }
    else
    {
        State *state = close.last();
        int count = 0;
        while (state != 0)
        {
            count++;
            temp = state->toString() + "\n" + temp;
            state = state->getParent();
        }

        temp += QObject::tr("Somme d'etapes necessaires : %1").arg(count);
    }

    return temp;
}

int MainWindow::choisirState(QList<State *> list)
{
    int min = 1000000;
    int pos = 0;
    for (int i = 0; i < list.length(); i++)
    {
        if (min > (list.at(i)->getH() + list.at(i)->getG()))
        {
            min = list.at(i)->getH() + list.at(i)->getG();
            pos = i;
        }
    }

    return pos;
}
